def get_prediction(rooms, appliances):
    # Example rule-based usage
    return (rooms * 50) + (appliances * 100)
