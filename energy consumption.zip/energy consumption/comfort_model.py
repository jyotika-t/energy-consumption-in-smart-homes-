def get_comfort_factor():
    # Example static comfort factor
    return 0.9
