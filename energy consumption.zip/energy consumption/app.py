from flask import Flask, request, jsonify

# ✅ Import your helper modules
import mobility_profile
import lz_trie
import prediction
import comfort_model

app = Flask(__name__)

@app.route("/", methods=["GET"])
def home():
    return """
    <h2>✅ Smart Home Energy Prediction API</h2>
    <p>POST JSON to <code>/predict</code> with keys: rooms, appliances</p>
    """

def predict_energy(data):
    rooms = data.get("rooms", 1)
    appliances = data.get("appliances", 1)

    # Use your helper modules
    profile = mobility_profile.get_profile()
    compressed = lz_trie.compress(profile)
    base = prediction.get_prediction(rooms, appliances)
    comfort = comfort_model.get_comfort_factor()

    # Example combined calculation
    final_usage = base * comfort

    return {
        "profile": profile,
        "compressed": compressed,
        "base_prediction": base,
        "comfort_factor": comfort,
        "energy_usage": final_usage
    }

@app.route("/predict", methods=["POST"])
def predict():
    input_data = request.json
    result = predict_energy(input_data)
    return jsonify(result)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
