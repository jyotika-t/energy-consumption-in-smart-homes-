def compress(data):
    # Dummy compression output
    return f"compressed({data})"
